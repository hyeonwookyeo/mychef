package recipe.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestMainController {
	
	@RequestMapping("testMain")
	public String testMain() {
		return "testMain";
	}
	
	/*
	 * String id = (String)session.getAttribute("id"); //메인에 후기 2개 출력 review rv1 =
	 * new review(); rv1 = service.toplist1();
	 * 
	 * review rv2 = new review(); rv2 = service.toplist2();
	 * 
	 * model.addAttribute("rv1", rv1); model.addAttribute("id",id);
	 * model.addAttribute("rv2", rv2); return "/main/layout2";
	 */

}
