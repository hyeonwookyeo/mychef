select * from recipe_jjim;

create table recipe_jjim (
	id varchar2(30),
	rnum number not null,
);