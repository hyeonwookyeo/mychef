package recipe.model;

public class MagaRecomBean {
	private int Maga_num;
	private String id;

	public int getMaga_num() {
		return Maga_num;
	}

	public void setMaga_num(int Maga_num) {
		this.Maga_num = Maga_num;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
