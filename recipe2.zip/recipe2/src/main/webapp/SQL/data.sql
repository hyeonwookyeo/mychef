INSERT INTO RECIPE VALUES ('1','마늘쫑고추장무침','https://recipe1.ezmember.co.kr/cache/recipe/2017/05/31/0995721c55330ff87ca6dacdd0c51ccd1.jpg','1',857000);
INSERT INTO RECIPE VALUES ('2','콩나물무침','https://recipe1.ezmember.co.kr/cache/recipe/2017/04/06/a1481111496916db9b160979b64377c41.jpg','1',1882000);
INSERT INTO RECIPE VALUES ('3','잡채','https://recipe1.ezmember.co.kr/cache/recipe/2019/09/12/9c5d89dcc77de2adb5bc95c7d3b1c9251.jpg','2',2706000);
INSERT INTO RECIPE VALUES ('4','오이소박이','https://recipe1.ezmember.co.kr/cache/recipe/2019/04/10/1acc383ddd59be9b33bde9b6e7e1d1921.jpg','3',732000);

INSERT INTO CUSTOMER VALUES ('1','뿡림이');
INSERT INTO CUSTOMER VALUES ('2','옐린84');
INSERT INTO CUSTOMER VALUES ('3','뽀유TV');

INSERT INTO FAVORITE VALUES ('1','1','Y');
INSERT INTO FAVORITE VALUES ('1','3','Y');
INSERT INTO FAVORITE VALUES ('2','1','Y');
INSERT INTO FAVORITE VALUES ('2','2','Y');
INSERT INTO FAVORITE VALUES ('2','3','Y');
INSERT INTO FAVORITE VALUES ('3','1','Y');
INSERT INTO FAVORITE VALUES ('4','3','Y');